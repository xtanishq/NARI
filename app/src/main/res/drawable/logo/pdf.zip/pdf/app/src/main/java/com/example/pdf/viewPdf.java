package com.example.pdf;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class viewPdf extends AppCompatActivity {

    String url1 = "https://demovisitor.000webhostapp.com/pdfstore/6305c80d93b5a..pdf";

    String url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_pdf);

        url = getIntent().getStringExtra("pdfUrl");
        Toast.makeText(this, url, Toast.LENGTH_SHORT).show();
        WebView browser = findViewById(R.id.webView);
        browser.getSettings().setJavaScriptEnabled(true);
        browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setAllowFileAccessFromFileURLs(true);
        browser.getSettings().setAllowUniversalAccessFromFileURLs(true);
        browser.loadUrl("https://docs.google.com/gview?embedded=true&url=" + url);
    }
}